const express = require('express');
const bodyParser = require('body-parser');
const { google } = require('googleapis');
const cors = require('cors');
const dotenv = require('dotenv');
const multer = require('multer');
const moment = require('moment-timezone');

// Load environment variables
dotenv.config();

// Validate required environment variables
if (!process.env.GOOGLE_CLOUD_PROJECT_ID || !process.env.GOOGLE_CLOUD_CLIENT_EMAIL || !process.env.GOOGLE_CLOUD_PRIVATE_KEY) {
  throw new Error('Missing required Google Cloud environment variables.');
}

const app = express();
const port = process.env.PORT || 3001;

const SCOPES = [
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/drive.file',
];

const auth = new google.auth.GoogleAuth({
  credentials: {
    type: 'service_account',
    project_id: process.env.GOOGLE_CLOUD_PROJECT_ID,
    private_key: process.env.GOOGLE_CLOUD_PRIVATE_KEY.replace(/\\n/g, '\n'),
    client_email: process.env.GOOGLE_CLOUD_CLIENT_EMAIL,
  },
  scopes: SCOPES,
});

const sheets = google.sheets({ version: 'v4', auth });

const corsOptions = {
  origin: ['https://formulariosloprado.cl', 'http://formulariosloprado.cl'],
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
};

app.use(cors(corsOptions));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));

const storage = multer.memoryStorage();
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

const SHEETS = {
  FORMULARIO: 'formulario',
  LOGS: 'logs',
};

// Log errors to Google Sheets
async function logToSheet(status, errorMessage, rawData) {
  try {
    const logData = [
      moment().tz('America/Santiago').format(),
      status,
      errorMessage || '',
      JSON.stringify(rawData || {}),
    ];
    await sheets.spreadsheets.values.append({
      spreadsheetId: process.env.SPREADSHEET_ID,
      range: `${SHEETS.LOGS}!A:D`,
      valueInputOption: 'USER_ENTERED',
      resource: { values: [logData] },
    });
  } catch (error) {
    console.error('Error logging to sheet:', error.message);
  }
}

// Handle duplicate RUT checking
async function checkDuplicateRUT(parentRUT, childrenRUTs) {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: process.env.SPREADSHEET_ID,
      range: `${SHEETS.FORMULARIO}!A2:W`,
    });

    const values = response.data.values || [];
    const existingRUTs = new Set(values.flatMap(row => [row[2], row[10], row[17]].filter(Boolean).map(rut => rut.trim())));

    if (existingRUTs.has(parentRUT.trim())) {
      return { isDuplicate: true, message: `El RUT ${parentRUT} ya está registrado` };
    }

    for (const childRUT of childrenRUTs) {
      if (childRUT && existingRUTs.has(childRUT.trim())) {
        return { isDuplicate: true, message: `El RUT ${childRUT} ya está registrado` };
      }
    }

    return { isDuplicate: false };
  } catch (error) {
    console.error('Error checking duplicate RUT:', error.message);
    throw new Error('Failed to check duplicate RUT.');
  }
}

// API route for form submission
app.post('/api/addData', upload.fields([{ name: 'parentDocument', maxCount: 1 }, { name: 'document', maxCount: 10 }]), async (req, res) => {
  try {
    console.log('Received request body:', req.body);
    const formData = req.body && typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    console.log('Parsed form data:', formData);

    if (!formData || !formData.parentRUT) {
      throw new Error('Invalid form data - missing required fields');
    }

    const childrenRUTs = formData.children?.map(child => child.childRUT).filter(Boolean) || [];
    const duplicateCheck = await checkDuplicateRUT(formData.parentRUT, childrenRUTs);

    if (duplicateCheck.isDuplicate) {
      await logToSheet('Error', duplicateCheck.message, formData);
      return res.status(400).json({ status: 'Failed', error: duplicateCheck.message });
    }

    // Add form data to spreadsheet
    const formValues = [
      formData[0] || '', // ID
      formData[1] || '', // Responsable
      formData[2] || '', // RUT_Resp
      formData[3] || '', // Dirección
      formData[4] || '', // Teléfono
      formData[5] || '', // Correo
      formData[6] || '', // N_Hijos
      formData[7] || '', // Res_Doc
      formData[8] || '', // Res_Parentesco
      formData[9] || '', // Hijo1_Nombre
      formData[10] || '', // Hijo1_RUT
      formData[11] || '', // Hijo1_FN
      formData[12] || '', // Hijo1_Genero
      formData[13] || '', // Hijo1_Nivel
      formData[14] || '', // Hijo1_Escuela
      formData[15] || '', // Hijo1_Doc
      formData[16] || '', // Hijo2_Nombre
      formData[17] || '', // Hijo2_RUT
      formData[18] || '', // Hijo2_FN
      formData[19] || '', // Hijo2_Genero
      formData[20] || '', // Hijo2_Nivel
      formData[21] || '', // Hijo2_Escuela
      formData[22] || '', // Hijo2_Doc
      formData[23] || moment().tz('America/Santiago').format(), // Fecha_Post
    ].map(value => value === undefined ? '' : value); // Ensure no undefined values

    await sheets.spreadsheets.values.append({
      spreadsheetId: process.env.SPREADSHEET_ID,
      range: `${SHEETS.FORMULARIO}!A:X`,
      valueInputOption: 'USER_ENTERED',
      resource: { values: [formValues] },
    });

    await logToSheet('Success', 'Form submitted successfully', formData);
    res.status(200).json({ status: 'Success', message: 'Data added successfully' });
  } catch (error) {
    console.error('Error processing request:', error);
    await logToSheet('Error', error.message, req.body);
    res.status(500).json({ status: 'Error', error: 'An unexpected error occurred. Please try again later.' });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Global error handler:', err);
  logToSheet('Error', err.message, req.body).catch(console.error);
  res.status(500).json({ status: 'Error', error: 'An unexpected error occurred. Please try again later.' });
});

// Start the server
const server = app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  logToSheet('Fatal Error', err.message).catch(console.error);
  server.close(() => {
    process.exit(1);
  });
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  logToSheet('Fatal Error', reason.message).catch(console.error);
});
